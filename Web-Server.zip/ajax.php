	<table id="example" class="table table-striped" style="width:100%">
        <thead>
            <tr>
                <th>İkon</th>
                <th>İsim</th>
                
            </tr>
        </thead>
        <tbody>
          

			 <?php
	$string = file_get_contents("liste.json");
$json_a = json_decode($string, true);
$oyunSayi= count($json_a);
	for ($i = 0; $i <= $oyunSayi; $i++){
		echo " 
		<tr>
		<td><img src='./ikonlar/".$json_a[$i]["dosya"].".ico' alt='".$json_a[$i]["isim"]."' height='32' width='32'></td>
		<td><a href='?dosya=".$json_a[$i]["dosya"]."&isim=".$json_a[$i]["isim"]."'>".$json_a[$i]["isim"]."</a></td>		
		</tr>";	
	}
	
	?>
                
           
     
    </table>