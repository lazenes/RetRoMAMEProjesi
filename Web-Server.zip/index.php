<?php
/*
Arcade Makina Otomosyonu Online
EnesBiBER.com.TR
*/
?>
<html>
	<head>
		<META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8">
	<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
	<title>Oyun Makinası Otomosyonu | Enes BİBER</title>
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/dataTables.bootstrap5.min.css">	
	<script type="text/javascript" language="javascript" src="https://code.jquery.com/jquery-3.5.1.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.11.3/js/dataTables.bootstrap5.min.js"></script>	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.5/bootstrap-notify.min.js"></script>
			<script type="text/javascript" class="init">	
$(document).ready(function() {
		
	 $('#loading').html('<marquee direction="right"><img src="./166.gif"></marquee> ');
	 $.ajax({
        type: "GET",       
        url: "ajax.php",
        success: function (d) {
			 $('#loading').html(d);
        $('#example').dataTable({
        "responsive": true,
        "dom": '<"html5buttons"B>lTfgitp',
        "language": {
        "url":"https://cdn.datatables.net/plug-ins/1.11.3/i18n/tr.json"
         }
    });
        }
    });
} );
				
				
	
var successClick = function () {
  $.notify({
    // options
    title: '<strong>Başarılı</strong>',
    message: "<br>Oyun Makinasına İstek<em><strong>Gönderildi</strong></em>",
    icon: 'glyphicon glyphicon-ok',    
     },
  {
    // settings
    element: 'body',
    //position: null,
    type: "success",
    //allow_dismiss: true,
    //newest_on_top: false,
    showProgressbar: false,
    placement: {
      from: "top",
      align: "right" },

    offset: 20,
    spacing: 10,
    z_index: 1031,
    delay: 3300,
    timer: 1000,
    url_target: '_blank',
    mouse_over: null,
    animate: {
      enter: 'animated fadeInDown',
      exit: 'animated fadeOutRight' },

    onShow: null,
    onShown: null,
    onClose: null,
    onClosed: null,
    icon_type: 'class' });

};		
				
				
				
	</script>
</head>
		<body class="wide comments example dt-example-bootstrap5">
	<div class="container">
		</br></br></br></br>
		<div class="card">
  <h5 class="card-header">Arcade Oyun Makinesi Online Otomosyon v1| Enes BİBER</h5>
  <div class="card-body">   
    <div id="loading"></div>
	<?php
			if(isset($_GET["dosya"])){
			$filename = './oyun.txt';
@ $fp = fopen($filename, 'wb');
if (!$fp)
{
    echo '<p><strong>Makineye İstek Gönderilemedi...</strong></p>';
    exit;
} 
else
{
	echo '<script>successClick();</script>';
$outputstring  = "[".json_encode($_GET)."]";
fwrite($fp, $outputstring);
}
			}
	?>
			</div>
			</html>
  

